function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  if (mouseX<width/2 & mouseY<height/2){
    fill('red')
    ellipse(width/2-100,width/2-100,20)  
  }
  else{
    for (var a = 1; a < 1000; a +=1)
      rect(random(width/2),random(height/2),4,4)
  }
  
  if (mouseX<width/2 & mouseY>height/2){
    fill('green')
    ellipse(width/2-100,height/2+100,20)
  }
  else{
    for ( var b = 1; b < 750; b +=1)
    rect(random(width/2200,width/2),random(height/2,height/2+200),4,4)
  }
  
  if (mouseX>width/2 & mouseY<height/2){
    fill('blue')
    ellipse(width/2+100,height/2-100,20)
  } 
    else{
      for (var c = 1; c < 750; c +=1)
    rect(random(width/2,width/2+200),random(height/2200,height/2),4,4)
    }
  
  if (mouseX>width/2 & mouseY>height/2){
    fill('yellow')
    ellipse(width/2+100,height/2+100,20)
  }
  else{
    for (var d = 1; d < 750; d +=1)
    rect(random(width/2,width/2+200),random(height/2,height/2+200),4,4)
  }
    
  
    
}