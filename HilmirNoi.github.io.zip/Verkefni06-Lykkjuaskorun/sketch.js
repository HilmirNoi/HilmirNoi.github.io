var centerX = 200
var centerY = 200

function setup() {
  createCanvas(400, 400);
  frameRate(2)
  colorMode(RGB)
}

function draw() {
  background(255,215,0);
  
  for (var x = 0; x < 10; x=x+1) {
      fill(random(0, 255), random(0,255), random(0, 255));
      var radius = 300 - x * 30;
      ellipse(centerX, centerY, radius, radius);
  }
}
