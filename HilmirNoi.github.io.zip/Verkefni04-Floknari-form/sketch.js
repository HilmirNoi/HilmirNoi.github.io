var centerX = 200
var centerY = 200

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  //draw mountain
  beginShape();
  strokeWeight(1)
  fill(160,170,255)
  vertex(centerX-200,centerY+200)
  vertex(centerX-160,centerY+150)
  vertex(centerX-148,centerY+165)
  vertex(centerX-135,centerY+145)
  vertex(centerX-130,centerY+150)
  vertex(centerX-50,centerY+50)
  vertex(centerX-20,centerY-25)
  vertex(centerX-8,centerY-50)
  vertex(centerX+10,centerY-25)
  vertex(centerX+20,centerY+45)
  vertex(centerX+40,centerY+70)
  vertex(centerX+50,centerY+58)
  vertex(centerX+80,centerY+100)
  vertex(centerX+100,centerY+120)
  vertex(centerX+110,centerY+105)
  vertex(centerX+115,centerY+110)
  vertex(centerX+120,centerY+120)
  vertex(centerX+125,centerY+125)
  vertex(centerX+150,centerY+145)
  vertex(centerX+200,centerY+200)
  endShape();
  
  beginShape();
  vertex()
  endShape();

}