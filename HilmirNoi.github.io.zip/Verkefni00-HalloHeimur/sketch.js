// Hér kemur kóðinn þinn:

function setup(){
    createCanvas(300,300);
    background(0,255,0);
    fill(150);
    ellipse(100,100,50,50);
    fill(0);
    textSize(20);
    text("Halló heimur",200,40);
}
