var faceWidth = 110
var faceHeight = 125
var eyeSize = 20 
var faceX = 200
var faceY = 200
var leftEyeX = 180
var rightEyeX = 220
var eyeY = 200
var mouthX = 200
var mouthHeight = 10
var hatHeight = 30


function setup() {
  createCanvas(400, 400);
  
}

function draw() {
  background(220);
  fill(255)
  
  //draw face and eyes
  ellipse(faceX,faceY,faceWidth,faceHeight)
  ellipse(leftEyeX,eyeY,eyeSize)
  ellipse(rightEyeX,eyeY,eyeSize)
  
  //varibles for drawing the mouth
  var mouthY = 230+faceHeight/12
  var mouthWidth = faceWidth/2
  
  //draw mouth
  ellipse(mouthX,mouthY,mouthWidth,mouthHeight)
  
  //variables for drawing the hat
  var hatWidth = faceWidth*1.2
  var hatX = faceX
  
  //draw hat
  fill(0)
  beginShape();
  curveVertex(hatX - hatWidth/2,163)
  curveVertex(hatX - hatWidth/2,163)
  curveVertex(hatX - hatWidth/3,128 - faceHeight/5)
  curveVertex(hatX,133 - faceHeight/5)
  curveVertex(hatX + hatWidth/3,128 -  faceHeight/5)
  curveVertex(hatX + hatWidth/2,163)
  curveVertex(hatX + hatWidth/2,163)
  endShape();
  
  //draw line at the bottom of the hat
  line(hatX - hatWidth/1.3,163,hatX + hatWidth/1.3,163)
}

//changes made to the drawing when mouse1 is pressed
function mousePressed() {
  eyeSize = random(10,35)
  eyeY = random(190,210)
  faceWidth = random(90,200)
  faceHeight = random(100,210)

  
  //print information about the variable values
  print('the value of eyeSize is ' + eyeSize)
  print('the value of eyeY is ' + eyeY)
  print('the value of faceWidth is ' + faceWidth)
  print('the value of faceHeight is ' + faceHeight)
  print('the value of mouthWidth is ' + mouthWidth)
  print('the value of mouthY is ' + mouthY)
 
}

