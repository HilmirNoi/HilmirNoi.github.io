function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  strokeWeight(0)
  fill('red')
  ellipse(200,200,300,300)
  fill('orange')
  ellipse(200,200,250,250)
  fill('white')
  strokeWeight(1)
  ellipse(200,260,70,70)
  ellipse(200,200,50,50)
  ellipse(200,160,30,30)
  strokeWeight(3)
  point(200,200)
  point(200,210)
  point(200,190)
  point(195,160)
  point(205,160)
  point(200,163)
  point(200,260)
  point(200,274)
  point(200,246)
  strokeWeight(1)
  line(175,200, 150,225)
  line(225,200, 250,225)
  line(180,145, 220,145)
  strokeWeight(0)
  fill('black')
  quad(188,145, 212, 145, 212,120, 188,120)
  fill('red')
  quad(188,142, 212,142, 212,137, 188,137)
  fill('red')
  quad(88,102, 102, 88, 302,288, 288,302)
  
  
}