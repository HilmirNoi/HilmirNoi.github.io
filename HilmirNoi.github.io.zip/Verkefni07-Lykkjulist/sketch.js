var centerY = 0
var startX = 0
var finishX = 400
var XChange = 10


function setup() {
  createCanvas(400, 400);
}

function draw() {
  frameRate(3)
  background(244, 164, 96);
  strokeWeight(0)
  fill('lightBlue')

  
  beginShape();
  curveVertex(0,200)
  for(var y = 200; y < 600; y +=10){
      curveVertex(y-200, 200 + random(10,20)*sin(y/10));
      }
  curveVertex(400,200)
  vertex(400,400)
  vertex(0,400)
  vertex(0,400)
      endShape();

}