function setup() {
    createCanvas(400, 400);
  }
  
  function draw() {
    background(220);
    fill('black')
    rect(0, 200, 400, 7);
    fill(196, 48, 36)
    rect(0, 0, 175, 200);
    fill('black')
    rect(175,0,8,400)
    fill('black')
    rect(360,200,7,200)
    rect(175,370,190,7)
    rect(360,280,40,10)
    rect(275,378,85,24);
    fill(246,213,50)
    rect(182,378,92,24)
    fill(29,70,142)
    rect(367,207,40,72)
    fill(236,237,232)
    rect(0,207,175,193)
    rect(182,0,318,200)
    rect(367,290,33,110)
    fill(236,238,227)
    rect(182,207,178,163)
  }  