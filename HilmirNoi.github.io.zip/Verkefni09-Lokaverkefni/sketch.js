var x = 0;
var y = 0;
var xSpeed = 2;
var ySpeed = 0;
var mass = 0.25;
var gravity = 9.8;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  ellipse(x, y, 50,50);// teikna hring
  x = x + xSpeed;//breyta x hniti hringsins eftir x-hraða
  y = y + ySpeed;//breyta y hniti eftir y-hraða
  ySpeed = ySpeed + gravity;//breyting á y-hraða
  gravity = mass * gravity;//breyting á þyngardkrafti

/*lætur boltann snúa við ef að hann skildi fara út fyrir 
reitinn sem hann er að hreyfast í*/
  if ((x > width) || (x < 0)) {
    xSpeed = xSpeed * -1;
  }

  /*kemur í veg fyrir að boltinn fari út fyrir reitinn 
á y-ás*/
  if ((y >= height)||(y<0)) {
    ySpeed = ySpeed * -1;
  }
  
/*breytir lit á bakgrunni í hvert skipti sem að boltinn snertir einhverja hlið á reitinum sem að hann er í*/
  if ((y>400)||(y<0)||(x<0)||(x>400)){
    background(random(0,255),random(0,255),random(0,255))
  }
}
